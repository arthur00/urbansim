package interfaces;

/**
 * Interface for objects that can exist in a percentage selection
 * 
 */
public interface SelectableType {

}
