package classes;

public class Constants {
	public static float averageSpeed = 4f;
}
