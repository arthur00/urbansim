import ui.MainWindow;

public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		MainWindow m = new MainWindow();

		m.setVisible(true);
	}

}
