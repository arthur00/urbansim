package simulation;

public class Route extends SUMOInstruction {

	public Route(int departureTime, String xmlDefinition) {
		super(departureTime, xmlDefinition);
	}

}
