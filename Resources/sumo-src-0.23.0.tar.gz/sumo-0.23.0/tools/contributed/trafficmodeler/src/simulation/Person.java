package simulation;

/**
 * Abstract class representing a virtual person
 *
 */
public abstract class Person {
}
