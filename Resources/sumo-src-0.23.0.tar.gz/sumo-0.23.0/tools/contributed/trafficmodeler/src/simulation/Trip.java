package simulation;

/**
 * Class representing a trip
 *
 */
public class Trip extends SUMOInstruction {

	public Trip(int departureTime, String xmlDefinition) {
		super(departureTime, xmlDefinition);
	}
}
