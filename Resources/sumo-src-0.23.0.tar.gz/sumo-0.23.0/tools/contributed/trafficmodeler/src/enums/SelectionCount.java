package enums;

/**
 * @author  PapaleonLe01
 */
public enum SelectionCount {
	None,Single,Multiple;
}
