package enums;

/**
 * @author  PapaleonLe01
 */
public enum SelectionType {
	Add, Remove, New
}
