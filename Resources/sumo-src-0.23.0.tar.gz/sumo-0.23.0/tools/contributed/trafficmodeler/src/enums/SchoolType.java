package enums;

/**
 * @author  PapaleonLe01
 */
public enum SchoolType {
	Kindergarden, Elementary, Middle, High
}
