package enums;

/**
 * @author  PapaleonLe01
 */
public enum TrafficDefinitionLayerType {
	UserDefined, ActivityBased, Random;
}
