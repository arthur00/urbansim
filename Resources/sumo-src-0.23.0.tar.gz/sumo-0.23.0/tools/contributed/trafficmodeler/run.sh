#!/bin/bash
java -cp jar/colt.jar:bin Main
