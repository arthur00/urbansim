package de.psi.telco.sumoplayer.util;

public interface Point {
	public double getX();
	public double getY();
}
